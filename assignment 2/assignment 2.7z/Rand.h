#ifndef RAND_H
#define RAND_H
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
using namespace std;
class Rand{
public:
	Rand(string randfile);
	myrandom(int i);
	int randCount;
	int numRand;
	int* randVec;
};

#endif