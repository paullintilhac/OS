#!/bin/bash


g++ -std=gnu++11 -o sched *.cpp
chmod +x sched
