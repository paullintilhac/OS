To compile, simply type:

./make.sh <input file path> <rand file path>

and then to run the program, type:

./sched [-s<sched type>] [-v] inputfile randfile

note that the optional arguments can be passed in 
any order.

-Paul 
